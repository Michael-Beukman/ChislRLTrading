import numpy as np
import pandas as pd
import utils

# Random action agent
class Agent:
    def __init__(self) -> None:
        self.count = 0
        self.test = 0
            
    
    def reward_function(
        self,
        navs: list,
    ):
        return utils.gordon(navs)

    def decision_function(
        self,
        observation: dict, 
        prev_reward: int, 
        info: dict,
    ):
        
        if len(info.get('history', [])) == 0 or len(info.get('history', [])) == 1:
            self.test = 0
            self.count = 0
        
        # print("REW", prev_reward, self.count, len(info.get('history', [])))
        # print(observation)
        # print(prev_reward)
        # print(info)
        # exit()
        # Add complex logic here to determine what the agent has to do.
        # Buy and hold ;)
        # action = np.random.uniform(low=-0.02, high=0.02, size=(50,))
        action = np.zeros(50)
        L = 5
        i = self.test % len(action // L)
        action[i * L : (i+1)*L] = 0.2
        self.count += 1
        
        if self.count % 1000 == 0:
            action *= -1
            self.test += 1
        
        # Always return action as an np.array of length observation space.
        return action